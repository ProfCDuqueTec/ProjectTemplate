#ifndef TEMPLATE_HPP
#define TEMPLATE_HPP

#include <string>

std::string getGreeting();

#endif
