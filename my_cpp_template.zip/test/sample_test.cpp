#include "template.hpp"
#include <cassert>
#include <iostream>

int main() {
    assert(getGreeting() == "¡Hola, Mundo Pro++!");
    std::cout << "Test passed!" << std::endl;
    return 0;
}
