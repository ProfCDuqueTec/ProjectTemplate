#include "template.hpp"
#include <iostream>

int main() {
    std::cout << getGreeting() << std::endl;
    return 0;
}
