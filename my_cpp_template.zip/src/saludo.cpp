#include "template.hpp"

std::string getGreeting() {
    return "¡Hola, Mundo Pro++!";
}
